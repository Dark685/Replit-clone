import express from "express";
import cors from "cors";
import { PrismaClient } from "@prisma/client";

const app = express();
const prisma = new PrismaClient();

app.use(cors());
app.use(express.json());

// Register
app.post("/api/register", async (req, res) => {
  // TODO: Registration logic (hash pw, create user)
  res.json({ message: "Register endpoint stub" });
});

// Login
app.post("/api/login", async (req, res) => {
  // TODO: Login logic (check pw, return JWT)
  res.json({ message: "Login endpoint stub" });
});

// Get all projects (auth needed: left as open for stub)
app.get("/api/projects", async (req, res) => {
  // TODO: Auth check
  const projects = await prisma.project.findMany({
    include: { files: true }
  });
  res.json(projects);
});

// Create project
app.post("/api/projects", async (req, res) => {
  // TODO: Auth check and input validation
  const { name, description } = req.body;
  const project = await prisma.project.create({
    data: { name, description, userId: "stub-user-id" }
  });
  res.json(project);
});

// Code execution stub
app.post("/api/exec", async (req, res) => {
  // TODO: Receive code, language; sandbox execution in real build
  res.json({ result: "Code executed (stub)", output: "Hello, world!" });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`[server] Listening on port ${PORT}`);
});
