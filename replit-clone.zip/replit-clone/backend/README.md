# backend

# Backend - How to Run

For Prisma features, use Node.js for compatibility (not Bun). Steps:

1. Install dependencies:
   ```sh
   bun install
   ```
2. Build TypeScript:
   ```sh
   npx tsc
   ```
3. Run backend server:
   ```sh
   node index.js
   ```

Or run in one command after build:
```sh
cd backend
npx tsc && node index.js
```

To run:

```bash
bun run index.ts
```

This project was created using `bun init` in bun v1.2.8. [Bun](https://bun.sh) is a fast all-in-one JavaScript runtime.
